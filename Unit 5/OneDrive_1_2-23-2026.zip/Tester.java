public class Tester {
    public static void main(String[] args) {
        new MyFrame();

        // Go to MyPanel.paint() to see how shapes are drawn

       
       
    }
}